import numpy as np
import math
import functools
from sklearn import metrics
from sklearn import linear_model
from sklearn import datasets
# input:  1) train data (without labels) in the form of a N by d numpy array, where N is the number of training data points and d is the number of dimensions
#         2) trainlabels: labels for training data in the form of a N by 1 numpy vector, where N is the number of training data points
#         3) test: test data (without labels) in the form of a M by d numpy array, where M is the number of test data points and d is the number of dimensions
#
# output: 1) vector (numpy array) consisting of the predicted classes for the test data
#         2) the beta parameter of the model
# note: the labels should **not** be part of the train/test data matrices!

def logistic(x):
    out = np.exp(x)/(1+np.exp(x))
    return out

def logistic_insample(X, y, w):
    N, num_feat = X.shape
    E = 0
    for n in range(N):
        E = E + (1/N)*np.log(1/logistic(y)*np.dot(w, X[n,:]))
    return E

def logistic_gradient(X, y, w):
    N, _ = X.shape
    g = 0*w
    for n in range(N):
        g = g + (-y[n] * X[n] * logistic(-y[n]*np.dot(w,X[n])))
    return g/N

def logreg(train_data, train_labels, test_data):
    regr = linear_model.LogisticRegression()
    num_pts1 = len(train_data)
    num_pts2 = len(test_data)
    new_train = train_data
    new_test = test_data
    # print(np.shape(new_train))
    # print(np.shape(test_data))
    # for t in range(len(train_labels)):
    #     if train_labels[t] == 0:
    #         train_labels[t] = -1
    onevec1 = np.ones((num_pts1,1))
    onevec2 = np.ones((num_pts2,1))
    # for i in range(len(train_labels)):
    #     onevec2[i] = train_labels[i]
    X = np.concatenate((onevec1, new_train), axis = 1)
    Y = np.concatenate((onevec2, new_test), axis = 1)
    regr.fit(X, train_labels)
    #print regr.coef_
    predicted = regr.predict(Y)
    # classes = metrics.classification_report(train_labels, predicted)
    # confusion = metrics.confusion_matrix(train_labels, predicted)
    # classes = []
    # for p in predicted:
    #     if p[19] > 0:
    #         classes.append(1)
    #     else:
    #         classes.append(0)
    #print (len(predicted))
    return predicted, regr.coef_
    # X is a d by N data matrix of input values
    # num_pts, num_feat = train_data.shape
    # onevec = np.ones((num_pts,1))
    # X = np.concatenate((onevec, train_data), axis = 1)
    # #dplus1 = num_feat + 1
    #
    # # y is a N by 1 matrix of target values -1 and 1
    # y = train_labels
    #
    # # Initialize learning rate for gradient descent
    # #learningrate = 1
    #
    # # Initialize weights at time step 0
    # w = 1*np.random.randn(num_feat + 1)
    #
    # # Compute value of logistic log likelihood
    # value = logistic_insample(X,y,w)
    #
    # num_iter = 0
    # convergence = 0
    #
    # # Keep track of function values
    # E_in = []
    #
    # while convergence == 0:
    #     num_iter = num_iter + 1
    #     print "sihgt"
    #     # Compute gradient at current w
    #     g = logistic_gradient(X,y,w)
    #
    #     # Set direction to move and take a step
    #
    #     ##############################################################
    #
    #     w_new = -g
    #
    #     #################################################################
    #
    #     # Check for improvement
    #     # Compute in-sample error for new w
    #     cur_value = logistic_insample(X,y,w_new)
    #     if cur_value < value:
    #         w = w_new
    #         value = cur_value
    #         E_in.append(value)
    #         #learningrate *=1
    #     #else:
    #         #learningrate *= 0
    #
    #     # Determine whether we have converged: Is gradient norm below
    #     # threshold, and have we reached max_iter?
    #
    #     g_norm = np.linalg.norm(g)
    #     if g_norm < 20000:
    #         convergence = 1
    #     elif num_iter > 20:
    #         convergence = 1


train_data = np.loadtxt('DD_train.txt')
test_data = np.loadtxt('DD_test.txt')
train_labels = np.loadtxt('DD_train_labels.txt')

print logreg(train_data, train_labels, test_data)
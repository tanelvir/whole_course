import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import t
# data is the datamatrix of the smoking dataset, e.g. as obtained by data = numpy.loadtxt('smoking.txt')
# should return True if the null hypothesis is accepted and False otherwise
def hyptest(data):
    non_smoker_list = []
    smoker_list = []
    for i in range(len(data)):
        if data[i,4] == 0.0:
            non_smoker_list.append(data[i,1])
        else:
            smoker_list.append(data[i,1])
    non_mean = np.mean(non_smoker_list)
    smoker_mean = np.mean(smoker_list)
    non_sd = np.std(non_smoker_list)
    smoker_sd = np.std(smoker_list)
    ti1 = (smoker_mean-non_mean)
    ti2 = np.sqrt(((smoker_sd**2)/len(smoker_list))+((non_sd**2)/len(non_smoker_list)))
    ti = ti1/ti2
    #print ti
    v_upper = (((smoker_sd**2)/len(smoker_list))+((non_sd**2)/len(non_smoker_list)))**2
    v_lower_left = (smoker_sd**4)/(len(smoker_list)**2*(len(smoker_list)-1))
    v_lower_right = (non_sd**4)/(len(non_smoker_list)**2*(len(non_smoker_list)-1))
    v = np.floor(v_upper/(v_lower_left + v_lower_right))
    #print v
    t_value = 2*t.cdf(-ti, v)
    #print t_value
    significance_value = 0.05
    if t_value > significance_value:
        return 0
    else:
        return 1

#data = np.loadtxt('C:\Users\Taneli\Downloads\data_analysis\smoking.txt')
#hyptest(data)
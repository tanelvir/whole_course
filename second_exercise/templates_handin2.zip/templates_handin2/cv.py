
# input:  1) training data in the form of a N by d numpy array, where N is the number of training data points and d is the number of dimensions
#         2) training labels in the form of a N by 1 numpy vector, where N is the number of training data points
#         3) a random permutation of entries as a numpy array, e.g. np.random.permutation(len(trainlabels))
# output: 1) the optimal k
#         2) an error matrix (numpy array) of size (5,13) where column i consists of the accuracy for the 5 folds for k=i
#
# The random-permuted vector rand_perm should be used for generating 5 folds, where the first fold consists of the first N/5 elements from rand_perm, rounded up to the nearest integer; the second fold consists of the next N/5 elements, etc, and the fifth fold consists of the remaining elements
# note: to create the folds consider: KFold(len(trainlabels), n_folds=5) from sklearn.cross_validation (http://scikit-learn.org/stable/modules/generated/sklearn.cross_validation.KFold.html)
# note: once you have the folds use the rand_perm vector to get the random indices in the training data and labels
def cv(train, trainlabels, rand_perm):
    pass

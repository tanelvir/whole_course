# input: train: 1) train data (without labels) in the form of a N by d numpy array, where N is the number of training data points and d is the number of dimensions
#               2) test: test data (without labels) in the form of a M by d numpy array, where M is the number of test data points and d is the number of dimensions
#               3) trainlabels: labels for training data in the form of a N by 1 numpy vector, where N is the number of training data points
#               4) k: paramater k
# output:1) distance matrix (numpy array) between test and training samples 
#        2) vector (numpy array) consisting of the predicted classes for the test data
#
# note: the labels should **not** be part of the train/test data matrices!
def knn(train, test, trainlabels, k):
    pass


import numpy as np

def kmeans(data, seedIndices):
	cluster_center = []
	for i in range(len(seedIndices)):
		cluster_center.append(data[seedIndices[i]])
	cluster_vector = np.ones(len(data))
	times = 0
	while (times < 50):
		times += 1
		for i in range(len(data)):
			temp_best = 100000
			best_k = 0
			for k in range(len(cluster_center)):
				temp = np.linalg.norm(data[i] - cluster_center[k])
				if temp <= temp_best:
					temp_best = temp
					best_k = k
			cluster_vector[i] = best_k

		for c in range(len(cluster_center)):
			temp_vec = []
			for d in range(len(cluster_vector)):
				if (cluster_vector[d] == c):
					temp_vec.append(data[d])
			cluster_center[c] = np.mean(temp_vec, axis=0)

	return cluster_center, cluster_vector

# input: 1) Datamatrix as loaded by numpy.loadtxt()
#        2) Random datamatrix of same size as input 1
#        3) numpy array of length 10 with initial center indices
# output: vector (numpy array) conisting of the gap statistics for k=1..10
# note this function should be called 10 times and averaged for the report.

def eval_clustering(data, randomData, initialCenters):
	E_k_d = np.ones(len(initialCenters), dtype=float)
	E_k_r = np.ones(len(initialCenters), dtype=float)
	for k in range(len(initialCenters)):
		cluster_center, cluster_vector = kmeans(data, initialCenters[:k+1])
		E_k_d[k] = objective_function_kmeans(data, cluster_center, cluster_vector)
		cluster_center, cluster_vector = kmeans(randomData, initialCenters[:k+1])
		E_k_r[k] = objective_function_kmeans(randomData, cluster_center, cluster_vector)
	gap_vector = gap_statistics(E_k_r, E_k_d)
	return gap_vector

# input:  	1) datamatrix as loaded by numpy.loadtxt()
#			2) numpy array of the cluster centers.
#			3) vector (numpy array) consisting of the assigned cluster for each observation.
# output:	the k-means objective function value as specified in the assignment for the given k
# note k is infered based on number of elements in centers
def objective_function_kmeans(data,centers,clusterLabels):
	tot_vec = 0.0
	for k in range(len(centers)):
		for i in range(len(clusterLabels)):
			if (k == clusterLabels[i]):
				tot_vec += np.linalg.norm(data[i] - centers[k])**2
	return tot_vec

# input:  	1) vector (numpy array) of objective function values for k=1..10 for a random dataset
#			2) vector (numpy array) of objective function values for k=1..10 for a given dataset
# output:	vector (numpy array) of the computed gap statistics for each k=1..10
# note should calculate step 4 in 4.a in assignment description
def gap_statistics(Erand,E):
	return np.log(Erand)-np.log(E)

data = np.loadtxt('Irisdata.txt')
k = [1,2,3,4,5,6,7,8,9,10]
eval_clustering(data, data, k)

import numpy as np
# input:  	1) datamatrix as loaded by numpy.loadtxt('Irisdata.txt').
#			2) vector (numpy array) of indices for k seed observation.
# output: 	1) numpy array of the resulting cluster centers. 
#			2) vector (numpy array) consisting of the assigned cluster for each observation.
# note the indices are an index to an observation in the datamatrix
def kmeans(data, seedIndices):
	cluster_center = []
	for i in range(len(seedIndices)):
		cluster_center.append(data[seedIndices[i]])
	cluster_vector = np.ones(len(data))
	times = 0
	while (times < 500):
		copy_cluster = cluster_vector
		times += 1
		for i in range(len(data)):
			temp_best = 100000
			best_k = 0
			for k in range(len(cluster_center)):
				temp = np.linalg.norm(data[i] - cluster_center[k])
				if temp <= temp_best:
					temp_best = temp
					best_k = k
			cluster_vector[i] = best_k

		for c in range(len(cluster_center)):
			temp_vec = []
			for d in range(len(cluster_vector)):
				if (cluster_vector[d] == c):
					temp_vec.append(data[d])
			cluster_center[c] = np.mean(temp_vec, axis=0)

	print cluster_vector
	return cluster_center, cluster_vector

data = np.loadtxt('Irisdata.txt')
k = [1]
#print np.shape(data)[1]
kmeans(data, k)
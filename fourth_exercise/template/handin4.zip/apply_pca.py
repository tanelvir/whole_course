import numpy as np
import matplotlib.markers as mark
# input: Datamatrix as loaded by numpy.loadtxt('Irisdata.txt')
# output: Datamatrix of the projected data onto the two first principal components.

def covariance(data):
    length = data.shape[1]
    new_cov = np.empty((length, length))
    for i in range(length):
        new_cov[i, i] = np.mean(data[:, i] * data[:, i])
        for j in range(length):
            new_cov[i, j] = new_cov[j, i] = np.mean(data[:, i] * data[:, j])
    return new_cov

def apply_pca(data):
    data -= np.mean(data, 0)
    data /= np.std(data, 0)
    Sigma = covariance(data)
    evals, evecs = np.linalg.eig(Sigma)
    indexes = np.argsort(evals)[::-1][:2]
    E, V = evals[indexes], evecs[:, indexes]
    print np.dot(V.T, data.T).T
    return np.dot(V.T, data.T).T

data = np.loadtxt('Irisdata.txt')
apply_pca(data)